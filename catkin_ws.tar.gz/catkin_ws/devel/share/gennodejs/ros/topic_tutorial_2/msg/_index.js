
"use strict";

let MyMsgs = require('./MyMsgs.js');
let MyMsgs = require('./MyMsgs.js');

module.exports = {
  MyMsgs: MyMsgs,
  MyMsgs: MyMsgs,
};
