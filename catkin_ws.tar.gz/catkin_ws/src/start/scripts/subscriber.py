#!/usr/bin/env python
import rospy
from std_msgs.msg import String
pub = rospy.Publisher('korea2', String, queue_size=10)
def walid(data):
   
    newdata = 'yyyyyyyyyy'
    print('hhhhhhhhhhhhhhhh')
    pub.publish(newdata)
    
    
def listener():
    rospy.init_node('listener_node', anonymous=True)
    

    rospy.Subscriber("korea", String, walid)
    print('i am getting data')
    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
    listener()